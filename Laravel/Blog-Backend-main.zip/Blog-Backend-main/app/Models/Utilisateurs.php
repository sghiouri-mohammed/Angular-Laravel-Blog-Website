<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Utilisateurs extends Model
{
    use  HasFactory;
        protected $fillable = [
        'username',
        'email',
        'fname',
        'lname',
        'city',
        'country',
        'gender',
        'zip',
        'about',
        'pdp',
        'role',
        'password'
    ];
}
