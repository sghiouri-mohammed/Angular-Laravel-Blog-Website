<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index(Request $request){

        $categ = Category::all();

        return response()->json([
            'status' => true,
            'message' => 'categories in the table ',
            'data'=>$categ
        ], 200);
    }

    public function showPerId(Request $request , $id){

        $varo = Category::find($id);

        return response()->json([
            'status' => true,
            'message' => ' found',
            'data'=>$varo
        ], 200);

    }

}
