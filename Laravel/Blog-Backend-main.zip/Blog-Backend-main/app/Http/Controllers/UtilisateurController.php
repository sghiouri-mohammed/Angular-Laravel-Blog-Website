<?php
namespace App\Http\Controllers;
use App\Models\Utilisateurs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Utilisateurcontroller extends Controller
{
    public function storeUser(Request $request){

        $data = $request->validate([
            'username' => 'required|string|max:60',
            'email' => 'required|string|max:60',
            'fname' => 'required|string|max:60',
            'lname' => 'required|string|max:60',
            'city' => 'required|string|max:60',
            'country' => 'required|string|max:60',
            'gender' => 'required|string|max:60',
            'zip' => 'required|string|max:60',
            'about' => 'nullable',
            'pdp' => 'required|string|max:60',
            'role' => 'required|string|max:60',
            'password' => 'required|string|max:60',
        ]);

        $data['about'] = $data['about'] ?: 'Set your bio.';

        $user = Utilisateurs::create($data);
        return response()->json([
            'status' => true,
            'message' => 'user created successfully',
            'data'=>$user,
        ], 201);

    }

    public function index(Request $request){

        $utilisateurs = Utilisateurs::all();

        return response()->json([
            'status' => true,
            'message' => 'Utilisateurs$Utilisateurs in the table ',
            'data'=>$utilisateurs
        ], 200);
    }

    public function showUserPerRole(Request $request,$role ){

        $results = DB::table('Utilisateurs')->where('role', 'like', '%'.$role.'%')->get();

        return response()->json([
            'status' => true,
            'message' => 'Blogs found',
            'data'=>$results

        ], 200);

    }

    public function indexAuthors(Request $request){

        $authors = Utilisateurs::where('role', 'blogger')->get();

        return response()->json([
            'status' => true,
            'message' => 'List of all bloggers',
            'data'=>$authors
        ], 200);
    }



    public function showPerId(Request $request , $id){

        $varo = Utilisateurs::find($id);

        return response()->json([
            'status' => true,
            'message' => ' found',
            'data'=>$varo
        ], 200);

    }

    public function updateUser(Request $request, $id){

        $data = $request->validate([
            'email' => 'nullable',
            'fname' => 'nullable',
            'lname' => 'nullable',
            'city' => 'nullable',
            'country' => 'nullable',
            'zip' => 'nullable',
            'about' => 'nullable',
        ]);

        $users = Utilisateurs::find($id);

        if ($users){

            $users->update($data);
            return response()->json([
                'status' => true,
                'message' => 'User updated successfully',
                'data'=>$users
            ], 200);

        }else{
            return response()->json([
                'status' => false,
                'message' => 'User not found',
                'data'=>null
            ], 404);

        }
    }


}


