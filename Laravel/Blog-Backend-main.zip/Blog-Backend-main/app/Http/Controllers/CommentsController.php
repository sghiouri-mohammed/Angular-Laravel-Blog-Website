<?php

namespace App\Http\Controllers;

use App\Models\Comments;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CommentsController extends Controller
{
    public function index(Request $request){

        $comments = Comments::all();

        return response()->json([
            'status' => true,
            'message' => 'commentsories in the table ',
            'data'=>$comments
        ], 200);
    }

    public function showPerId(Request $request , $id){

        $varo = Comments::find($id);

        return response()->json([
            'status' => true,
            'message' => ' found',
            'data'=>$varo
        ], 200);

    }
    public function storeComment(Request $request){

        $data = $request->validate([
            'id_blog'=>'nullable|max:255',
            'username'=>'nullable|string|max:255',
            'pdp'=>'nullable|string|max:255',
            'rank'=>'nullable|string|max:255',
            'comment'=>'nullable|string|max:255'
        ]);
        $comment = Comments::create($data);
        return response()->json([
            'status' => true,
            'message' => 'Comment created successfully',
            'data'=>$comment,
        ], 201);

    }

    public function showCommentsOfBlog(Request $request, $id_blog){

        $results = DB::table('Comments')->where('id_blog', 'like', '%'.$id_blog.'%')->get();

        return response()->json([
            'status' => true,
            'message' => 'Blogs found',
            'data'=>$results

        ], 200);
    }

    public function rating(Request $request){

        $ratings = Comments::select('rank')->get();

        return response()->json([
            'status' => true,
            'message' => 'ratings ',
            'data'=>$ratings
        ],201);
    }

    public function ranking(Request $request, $rank){

        $id_blog = request('id_blog');

        $ranking = DB::table('Comments')
            ->where('rank', 'like', $rank)
            ->where('id_blog', 'like', $id_blog)
            ->get();
        return response()->json([
            'status' => true,
            'message' => 'ratings ',
            'data'=>$ranking
        ],201);

    }
}
