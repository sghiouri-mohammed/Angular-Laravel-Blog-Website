<?php

namespace App\Http\Controllers;
use App\Models\Blogs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BlogController extends Controller
{

    public function index(Request $request){

        $blogs = Blogs::all();
        return response()->json([
            'status' => true,
            'message' => 'Blogs in the table ',
            'data'=>$blogs
        ], 200);
    }

    public function showPerName(Request $request , $author){

        $results = DB::table('Blogs')->where('author', 'like', '%'.$author.'%')->get();

        return response()->json([
            'status' => true,
            'message' => 'Blogs found',
            'data'=>$results

        ], 200);

    }


    public function showBlogPerIdCategory(Request $request , $id_category){

        $results = DB::table('Blogs')->where('id_category', 'like', '%'.$id_category.'%')->get();

        return response()->json([
            'status' => true,
            'message' => 'Blogs found',
            'data'=>$results

        ], 200);

    }


    public function last(Request $request , $id_category)
    {
        $last = Blogs::where('id_category', 'like', '%'.$id_category.'%')->latest()->first();
        return response()->json($last);
    }

    public function lasto(Request $request )
    {
        $last = Blogs::latest()->first();
        return response()->json($last);
    }

    public function showPerId(Request $request , $id){

        $blogs_id = Blogs::find($id);

        return response()->json([
            'status' => true,
            'message' => 'Blogs found',
            'data'=>$blogs_id
        ], 200);

    }
    public function storeBlog(Request $request){

        $data = $request->validate([
            'title' => 'required|string|max:255',
            'author' => 'required|string|max:255',
            'date'=>'required|string|max:255',
            'id_category'=>'required|string|max:255',
            'time'=>'required|string|max:255',
            'article'=>'required|string|max:255',
            'image'=>'required|string|max:255'
        ]);

        $blog = Blogs::create($data);

        return response()->json([
            'status' => true,
            'message' => 'Blog created successfully',
            'data'=>$blog,
        ], 201);

    }

    public function updateBlog(Request $request, $id){

        $data = $request->validate([
            'title' => 'nullable|string|max:255',
            'author' => 'nullable|string|max:255',
            'content'=>'nullable|string|max:255'
        ]);

        $blogs_id = Blogs::find($id);

        if ($blogs_id){

            $blogs_id->update($data);
            return response()->json([
                'status' => true,
                'message' => 'Blogs updated successfully',
                'data'=>$blogs_id
            ], 200);

        }else{
            return response()->json([
                'status' => false,
                'message' => 'Blogs not found',
                'data'=>null
            ], 404);

        }
    }


    public function deleteBlog(Request $request, $id){

        $blog = Blogs::find($id);

        if($blog){
            $blog->delete();

            return response()->json([
                'status' => true,
                'message' => 'Blog deleted',
                'data'=>$blog
            ],201);

        }else{
            return response()->json([
                'status' => false,
                'message' => 'Blog not found',
                'data'=>null
            ], 404);
        }

    }

}
