<?php

namespace App\Http\Controllers;


use App\Models\Roles;
use Illuminate\Http\Request;

class RoleController extends Controller
{
    public function index(Request $request){

        $roles = Roles::all();

        return response()->json([
            'status' => true,
            'message' => 'roles in the table ',
            'data'=>$roles
        ], 200);
    }

    public function showPerId(Request $request , $id){

        $varo = Roles::find($id);

        return response()->json([
            'status' => true,
            'message' => ' found',
            'data'=>$varo
        ], 200);

    }
}
