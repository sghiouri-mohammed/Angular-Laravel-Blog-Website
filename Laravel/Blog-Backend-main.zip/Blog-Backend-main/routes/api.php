<?php

use App\Http\Controllers\BlogController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CommentsController;
use App\Http\Controllers\UtilisateurController;
use App\Http\Controllers\RoleController;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// ----------------------------------------------------------------
Route::get('/blogs', [BlogController::class, 'index']);
Route::get('/utilisateurs', [UtilisateurController::class, 'index']);
Route::get('/comments', [CommentsController::class, 'index']);
Route::get('/category', [CategoryController::class, 'index']);
Route::get('/role', [RoleController::class, 'index']);
Route::get('/authors', [UtilisateurController::class, 'indexAuthors']);
Route::get('/rating', [CommentsController::class, 'rating']);
// ----------------------------------------------------------------
Route::get('/blogs/{id}', [BlogController::class, 'showPerId']);
Route::get('/userRole/{id}', [UtilisateurController::class, 'showUserPerRole']);
Route::get('/BlogsOfAuthor/{author}', [BlogController::class, 'showPerName']);
Route::get('/blogsOfCtegory/{id_category}', [BlogController::class, 'showBlogPerIdCategory']);
Route::get('/lastBlog/{id_category}', [BlogController::class, 'last']);
Route::get('/lastBlogg', [BlogController::class, 'lasto']);
Route::get('/blogsAuthors/{id}', [BlogController::class, 'showBlog']);
Route::get('/utilisateurs/{id}', [UtilisateurController::class, 'showPerId']);
Route::get('/comments/{id}', [CommentsController::class, 'showPerId']);
Route::get('/category/{id}', [CategoryController::class, 'showPerId']);
Route::get('/role/{id}', [RoleController::class, 'showPerId']);
Route::get('/category/{name}', [CategoryController::class, 'showPerName']);
Route::get('/commentsOfBlog/{id_blog}', [CommentsController::class, 'showCommentsOfBlog']);
Route::get('/rankOfAComment/{rank}', [CommentsController::class, 'ranking']);
Route::get('/listOfRanks/{id_blog}', [CommentsController::class, 'rating']);
// ----------------------------------------------------------------
Route::post('/createblog', [BlogController::class, 'storeBlog']);
Route::post('/createuser', [UtilisateurController::class, 'storeUser']);
Route::post('/createComment', [CommentsController::class, 'storeComment']);
// ----------------------------------------------------------------
Route::patch('/updateBlog/{id}',[BlogController::class, 'updateBlog']);
Route::patch('/updateUser/{id}',[UtilisateurController::class, 'updateUser']);

// ----------------------------------------------------------------
Route::delete('/deleteBlog/{id}',[BlogController::class, 'deleteBlog']);

Route::get('/message', function () {
    return response()->json([
        'message' => 'This is an API',
        'status_code' => 200
    ]);
});

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
