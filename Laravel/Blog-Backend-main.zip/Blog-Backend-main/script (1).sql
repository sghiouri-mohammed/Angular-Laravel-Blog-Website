SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
CREATE DATABASE IF NOT EXISTS `penmind` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `penmind`;

CREATE TABLE `role` (
  `id` int NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `user` (
  `id` int NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `about` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pdp` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int NOT NULL,
  `password` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `category` (
  `id` int NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `blog` (
  `id` int NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` int NOT NULL,
  `date` date NOT NULL,
  `id_category` int NOT NULL,
  `time` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `article` varchar(4000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `blogCategory` (
  `id` int NOT NULL,
  `id_blog` int NOT NULL,
  `id_category` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `comments` (
  `id` int NOT NULL,
  `id_blog` int NOT NULL,
  `id_user` int NOT NULL,
  `rank` int NOT NULL,
  `date` date NOT NULL,
  `comment` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `blogCategory`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

ALTER TABLE `category`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

ALTER TABLE `role`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

ALTER TABLE `blog`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

ALTER TABLE `blogCategory`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

ALTER TABLE `comments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;


ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `blog`
  ADD CONSTRAINT `author_ibfk_1` FOREIGN KEY (`author`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `blogCategory`
  ADD CONSTRAINT `blog_ibfk_1` FOREIGN KEY (`id_blog`) REFERENCES `blog` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `blogCategory`
  ADD CONSTRAINT `cat_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `category` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `comments`
  ADD CONSTRAINT `commblog_ibfk_1` FOREIGN KEY (`id_blog`) REFERENCES `blog` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `comments`
  ADD CONSTRAINT `commuser_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


INSERT INTO `role` VALUES (1, 'admin');
INSERT INTO `role` VALUES (2, 'blogger');
INSERT INTO `role` VALUES (3, 'user');

INSERT INTO `user` VALUES (1, 'loubnaelattar', 'loubnaelattar@gmail.com', 'Loubna', 'El Attar', 'Rabat', 'Morocco', '21000', 'Tech Enthusiast excited about AI, Data Sciencem ML & Blockchain',
'loubna.jpg', 1, 'test');

INSERT INTO `user` VALUES (2, 'mohammedsghiouri', 'mohammedsghiouri@gmail.com', 'Mohammed', 'Sghiouri', 'Casablanca', 'Morocco', '12330', 'Full Stack Developer',
'cmo.jpg', 1, 'test');

INSERT INTO `user` VALUES (3, 'victorhugo', 'victorhugo@gmail.com', 'Victor', 'Hugo', 'Paris', 'France', '21000', 'Writer, Thinker, Poet & Novelist',
'victor.jpg', 2, 'test');

INSERT INTO `user` VALUES (4, 'aliskali', 'aliskali@gmail.com', 'Ali', 'Skali', 'Casablanca', 'Morocco', '12330', 'I love to read and to discover the world',
'ali.jpg', 2, 'test');

INSERT INTO `user` VALUES (5, 'souadidrissi', 'souadidrissi@gmail.com', 'Souad', 'Idrissi', 'Casablanca', 'Morocco', '12330', 'I love to read and to discover the world',
'test.jpg', 3, 'test');

INSERT INTO `category`(`id`, `name`) VALUES (1, 'Tech & Science');
INSERT INTO `category`(`id`, `name`) VALUES (2, 'Lifestyle & Health');
INSERT INTO `category`(`id`, `name`) VALUES (3, 'Politics & History');
INSERT INTO `category`(`id`, `name`) VALUES (4, 'Pop Culture');
INSERT INTO `category`(`id`, `name`) VALUES (5, 'Book Reviews');


INSERT INTO `blog`(`id`, `title`, `author`, `date`, `id_category`, `time`, `article`, `image`) VALUES (1, 'AI Ethics', 1, 2023-01-29, 1, '5 min', 'Ethics is a set of moral principles which help us discern between right and wrong.
  AI ethics is a set of guidelines that advise on the design and outcomes of artificial intelligence. Human beings come with all sorts of cognitive biases,
  such as recency and confirmation bias, and those inherent biases are exhibited in our behaviors and subsequently, our data. Since data is the foundation
  for all machine learning algorithms, it’s important for us to structure experiments and algorithms with this in mind as artificial intelligence has the
  potential to amplify and scale these human biases at an unprecedented rate. With the emergence of big data, companies have increased their focus to drive
  automation and data-driven decision-making across their organizations. While the intention there is usually, if not always, to improve business outcomes,
  companies are experiencing unforeseen consequences in some of their AI applications, particularly due to poor upfront research design and biased datasets.
  As instances of unfair outcomes have come to light, new guidelines have emerged, primarily from the research and data science communities, to address concerns
  around the ethics of AI. Leading companies in the field of AI have also taken a vested interest in shaping these guidelines, as they themselves have started to
  experience some of the consequences for failing to uphold ethical standards within their products. Lack of diligence in this area can result in reputational,
  regulatory and legal exposure, resulting in costly penalties. As with all technological advances, innovation tends to outpace government regulation in new,
  emerging fields. As the appropriate expertise develops within the government industry, we can expect more AI protocols for companies to follow, enabling them
  to avoid any infringements on human rights and civil liberties.', 'ai.jpg');


INSERT INTO `blog`(`id`, `title`, `author`, `date`, `id_category`, `time`, `article`, `image`) VALUES (2, 'Book Review: Les Misérables, by Victor Hugo', 3, 2023-01-29, 5, '4 min', 'Les Miserables is big. Really, really big. Weighing in at about 1400 pages, its now the single longest book I have ever read. (A Dance to the Music of Time was longer, but while a single work, its technically twelve books.)
It took me about six months because damn, is Victor Hugo wordy. And the satire and the fantastical flavor that I found so entertaining when I read Notre-Dame de Paris, enough that I was able to overlook the fifty-page digressions on historical architecture, seemed to be missing here. Les Miserables is a much more serious book. There is some humor, though mostly dark, but Hugos purpose in writing it is right there in the title, The Miserables:
So long as there shall exist, by reason of law and custom, a social condemnation which, in the midst of civilization, artificially creates a hell on earth, and complicates with human fatality a destiny that is divine; so long as the three problems of the century - the degradation of man by the exploitation of his labour, the ruin of women by starvation and the atrophy of childhood by physical and spiritual night are not solved; so long as, in certain regions, social asphyxia shall be possible; in other words and from a still broader point of view, so long as ignorance and misery remain on earth, there should be a need for books such as this.', 'victor.jpg');

INSERT INTO `blog`(`id`, `title`, `author`, `date`, `id_category`, `time`, `article`, `image`) VALUES (3, 'Can I lose weight if my only exercise is walking?', 4, 2023-01-29, 2, '2 min', 'You might be able to lose weight that way, depending on how long and how intensely you walk and what your diets like.
A combination of physical activity and cutting calories seems to help with weight loss more than does exercise alone.
Physical activity, such as walking, is important for weight control because it helps you burn calories. If you add 30 minutes of brisk walking to your daily routine, you could burn about 150 more calories a day. Of course, the more you walk and the quicker your pace, the more calories you will burn.
However, balance is important. Overdoing it can increase your risk of soreness, injury and burnout. If you are new to regular exercise, you may need to start out with short walks or walking at a light intensity, and gradually build up to longer walks or more moderate or vigorous intensity.
Once you have lost weight, exercise is even more important. Its what helps keep the weight off. In fact, studies show that people who maintain their weight loss over the long term get regular physical activity.
So keep walking, but make sure you also eat a healthy diet.', 'walking.jpg');


INSERT INTO `blog`(`id`, `title`, `author`, `date`, `id_category`, `time`, `article`, `image`) VALUES (4, '‘Extraordinary’ Review: The Power of Powerlessness', 2, 2023-01-29, 4, '5 min', 'The heroine of “Extraordinary,” on Hulu, just wants to have a superpower so she can be like everyone else.
  On paper, the new British series “Extraordinary” sounds like a barbed response to the superhero glut in our popular culture. Its heroine, Jen (Máiréad Tyers), is defined by her lack of super: In a world where nearly everyone gains an unusual power when they turn 18, she’s still waiting for hers at 25.
But satire is not the only or even the primary objective of “Extraordinary,” which happens to come from inside the superhero-industrial complex — its eight episodes premiere on Wednesday on Hulu, Marvel’s corporate sibling. It has a lot of fun playing with the conventions of that currently dominant genre,
but it is equally representative of some other favorite modes of the Walt Disney Company: the sentimental buddy comedy and the inspirational triumph-of-the-underdog tale.There are many ways that blend could go wrong, but the show’s various strains are combined in a charming and consistently amusing fashion
by its creator and writer, Emma Moran, a young Northern Irish comedian with a short résumé; “Extraordinary” appears to be her first credit beyond “additional material.” It helps that Moran’s comic sensibility is dirty-mouthed and dirty-minded in a completely disarming, sometimes painfully funny way.', 'power.jpg');


